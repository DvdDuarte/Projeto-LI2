//
// Created by david on 12/03/20.
//

#include "estruturasDados.h"

// Estruturas de dados (devem ser colocadas no modulo correto da camada de dados)