//
// Created by david on 20/03/20.
//

#include "tipoErros.h"
