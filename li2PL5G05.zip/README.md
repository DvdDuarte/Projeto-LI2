# Projeto-LI2
MIEI - PL5 - Grupo 5 - 
> A93253 David Alexandre Ferreira Duarte;
> A82884 Carlos Manuel Cerqueira de Oliveira;
> A93236 Rodrigo Jorge Pinto Guimarães.

